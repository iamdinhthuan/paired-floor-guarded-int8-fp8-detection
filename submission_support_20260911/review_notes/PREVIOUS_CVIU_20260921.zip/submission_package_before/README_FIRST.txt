CVIU — FILES FOR SUBMISSION (11 September 2026)

01_CVIU_main_revised.pdf          Main manuscript (13 pages)
02_CVIU_supplement_revised.pdf    Supplementary Information (19 pages)
03_highlights_CVIU.txt            Highlights
04_graphical_abstract_CVIU.pdf    Graphical abstract
05_CVIU_cover_letter.pdf         Cover letter (confirm all-author approval)
07_Elsevier_Flat_Source_CVIU.zip  LaTeX source, when requested by the portal

Assign each file to the corresponding portal category. Do not upload this
README. Inspect the journal-generated PDF before approving submission.

Research evidence: https://doi.org/10.5281/zenodo.22664869
That archive preserves v2.2.0; the 11 September wording revision is local.

Editable source, Overleaf ZIP, evidence ZIP and audit files were moved to:
../submission_support_20260911/
No supporting files were deleted. For subsequent edits, use the relocated
source/main.tex and source/supplement.tex; rebuild the submission files.
