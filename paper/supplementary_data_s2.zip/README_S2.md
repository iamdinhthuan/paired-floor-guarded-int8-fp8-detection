# Supplementary Data S2

This archive contains compact manuscript-level ledgers, retained evidence
reports, SHA-256 audit records, and deterministic scripts supporting the article
“A Paired, Floor-Guarded Evaluation Protocol for TensorRT INT8 and FP8 Object
Detectors under Synthetic Image Corruptions.”

## Scope

The archive reproduces and validates manuscript-level summaries. It does not
rerun training, quantization, TensorRT engine construction, corruption
materialization, or detector inference. Raw datasets, checkpoints, engines, and
per-image prediction payloads are not included.

## Canonical signs

- `Q = AP_FP32 - AP_quantized`
- `E = Q_corrupt - Q_clean`
- `DeltaE = E_INT8 - E_FP8`
- equivalently, `DeltaE = (FP8-INT8)_corrupt - (FP8-INT8)_clean`

The architecture-portability mean INT8 `E` values are −6.81 AP for RT-DETR-L
and −6.21 AP for RetinaNet-R50-FPN-v2.

## Regeneration

From the parent manuscript package, run:

```bash
python3 scripts/make_decision_impact.py
python3 scripts/rebuild_cross_family_evidence.py
python3 scripts/validate_package.py
```

External filesystem paths inside retained JSON audits are provenance labels
from the original research environment; they are not required for the packaged
manuscript-level checks.
